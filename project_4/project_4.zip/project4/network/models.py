from django.contrib.auth.models import AbstractUser
from django.core import validators
from django.db import models


class User(AbstractUser):
    pass


class Post(models.Model):
    content = models.CharField(
        max_length=500,
        validators=[
            validators.MinLengthValidator(3, 'Post content needs to be at least 3 characters long.')
        ],
        null=False,
        blank=False
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    author = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE
    )


class Follower(models.Model):
    user = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE
    )

    follower = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE,
        related_name='user_follower'
    )
