
from django.urls import path

from . import views
from .views import FollowAndUnfollowUserAPIView

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("profile_page/<int:pk>", views.profile_page, name="profile-page"),
    path("create_post", views.create_post_view, name="create-post"),

    path("follow_user/<int:pk>", FollowAndUnfollowUserAPIView.as_view(), name='follow-unfollow-user-api-view')
]
