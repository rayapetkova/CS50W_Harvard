from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .forms import PostForm
from .models import User, Post, Follower
from .serializers import FollowerSerializer


def index(request):
    posts = Post.objects.all().order_by('-created_at')

    context = {
        'posts': posts
    }

    return render(request, 'network/index.html', context=context)


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "network/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "network/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "network/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "network/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "network/register.html")


def profile_page(request, pk):
    followers = [f_obj.follower for f_obj in Follower.objects.filter(user_id=pk)]
    following = [f_obj.user for f_obj in Follower.objects.filter(follower_id=pk)]

    user = User.objects.filter(id=pk).first()

    user_posts = Post.objects.filter(author_id=pk)

    current_user_following = [f_obj.user for f_obj in Follower.objects.filter(follower_id=request.user)]

    context = {
        'followers': followers,
        'following': following,
        'user': user,
        'user_posts': user_posts,
        'logged_in_user_follows_current_user': user in current_user_following
    }

    return render(request, 'network/profile_page.html', context=context)


def create_post_view(request):
    form = PostForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()

            return redirect('index')

    context = {
        'form': form
    }

    return render(request, 'network/create_post.html', context=context)


class FollowAndUnfollowUserAPIView(APIView):

    def post(self, request, pk):
        serializer = FollowerSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        follower_record = Follower.objects.filter(user_id=pk).first()
        serializer = FollowerSerializer(follower_record)

        if follower_record:
            follower_record.delete()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(status=status.HTTP_400_BAD_REQUEST)
