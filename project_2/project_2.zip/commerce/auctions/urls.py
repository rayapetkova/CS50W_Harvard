from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("create_listing", views.create_listing_view, name="create-listing"),
    path("watchlist", views.watchlist_view, name="watchlist"),
    path("categories", views.categories_view, name="categories"),
    path("listings/<int:pk>", views.listing_details_view, name="listing-details"),
    path("listings/<int:pk>/add_to_watchlist", views.add_listing_to_watchlist_view, name="add-listing-to-watchlist"),
    path("listings/<int:pk>/remove_from_watchlist", views.remove_listing_from_watchlist_view, name="remove-listing-from-watchlist"),
    path("listings/<int:pk>/close_auction", views.close_auction_view, name="close-auction-view")
]
