from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse

from .forms import ListingForm, BidForm, CommentForm
from .models import User, Listing, Watchlist, Bid, Comment


def index(request):
    listings = Listing.objects.all()

    category = request.GET.get('category')

    if category:
        listings = listings.filter(category=category)

    context = {
        'listings': listings
    }

    return render(request, "auctions/index.html", context=context)


def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")


@login_required
def create_listing_view(request):
    form = ListingForm(request.POST or None)

    if request.method == "POST":
        listing = form.save(commit=False)

        listing.author = request.user

        if form.is_valid():
            form.save()

            return redirect('index')

    context = {
        'form': form
    }

    return render(request, 'auctions/create_listing.html', context=context)


def listing_details_view(request, pk):
    listing = Listing.objects.filter(id=pk).first()
    bid_form = BidForm(request=request, listing_id=listing.id)
    comment_form = CommentForm(request=request, listing_id=listing.id)

    watchlist_record = Watchlist.objects.filter(user=request.user, listing=listing).first()

    highest_bid = Bid.objects.filter(
        price=listing.starting_bid,
        listing=listing,
        author=request.user
    ).first()

    comments = Comment.objects.filter(listing=listing)

    if request.method == "POST":
        if 'place_bid' in request.POST:
            bid_form = BidForm(request.POST or None, request=request, listing_id=listing.id)
            print("BIDDDDD")
            if bid_form.is_valid():
                bid_form.save()
                return redirect('listing-details', pk=pk)
        elif 'add_comment' in request.POST:
            comment_form = CommentForm(request.POST or None, request=request, listing_id=listing.id)
            print("COMMMMM")
            if comment_form.is_valid():
                comment_form.save()
                return redirect('listing-details', pk=pk)

    context = {
        'listing': listing,
        'bid_form': bid_form,
        'added_to_watchlist': True if watchlist_record else False,
        'won_auction': True if highest_bid and listing.is_closed else False,
        'comments': comments,
        'comment_form': comment_form
    }

    return render(request, 'auctions/listing_details.html', context=context)


def watchlist_view(request):
    watchlist_listings = Watchlist.objects.filter(user=request.user)

    context = {
        'watchlist_listings': watchlist_listings
    }

    return render(request, 'auctions/watchlist.html', context=context)


def categories_view(request):
    categories = ['Fashion', 'Toys', 'Electronics', 'Home', 'School']

    context = {
        'categories': categories
    }

    return render(request, 'auctions/categories.html', context=context)


@login_required
def add_listing_to_watchlist_view(request, pk):
    listing = Listing.objects.filter(id=pk).first()

    Watchlist.objects.create(
        user=request.user,
        listing=listing
    )

    return redirect('listing-details', pk=pk)


@login_required
def remove_listing_from_watchlist_view(request, pk):
    listing = Listing.objects.filter(id=pk).first()

    watchlist_record = Watchlist.objects.filter(
        user=request.user,
        listing=listing
    )

    watchlist_record.delete()

    return redirect('listing-details', pk=pk)


def close_auction_view(request, pk):
    listing = Listing.objects.filter(id=pk).first()

    if request.user == listing.author and not listing.is_closed:
        listing.is_closed = True
        listing.save()

        return redirect('listing-details', pk=pk)

    return redirect('listing-details', pk=pk)

