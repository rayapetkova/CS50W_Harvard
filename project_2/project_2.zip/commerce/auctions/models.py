from django.contrib.auth.models import AbstractUser
from django.core import validators
from django.db import models


class User(AbstractUser):
    pass


class Listing(models.Model):

    CATEGORY_CHOICES = (
        ('Fashion', 'Fashion'),
        ('Toys', 'Toys'),
        ('Electronics', 'Electronics'),
        ('Home', 'Home'),
        ('School', 'School')
    )

    title = models.CharField(
        max_length=150,
        validators=[
            validators.MinLengthValidator(2, "Title needs to be at least 2 characters long.")
        ],
        null=False,
        blank=False
    )

    description = models.CharField(
        max_length=300,
        validators=[
            validators.MinLengthValidator(10, "Description needs to be at least 10 characters long.")
        ],
        null=False,
        blank=False
    )

    starting_bid = models.PositiveIntegerField(
        null=False,
        blank=False
    )

    poster_image = models.URLField(
        null=True,
        blank=True
    )

    category = models.CharField(
        max_length=30,
        choices=CATEGORY_CHOICES,
        null=True,
        blank=True
    )

    is_closed = models.BooleanField(
        default=False
    )

    author = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE,
        related_name='user_listings'
    )


class Bid(models.Model):
    price = models.PositiveIntegerField(
        null=False,
        blank=False
    )

    listing = models.ForeignKey(
        to=Listing,
        on_delete=models.CASCADE
    )

    author = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE
    )


class Comment(models.Model):
    content = models.CharField(
        max_length=100,
        validators=[
            validators.MinLengthValidator(2, "Comment needs to be at least 2 characters long.")
        ],
        null=False,
        blank=False
    )

    listing = models.ForeignKey(
        to=Listing,
        on_delete=models.CASCADE
    )

    author = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE
    )


class Watchlist(models.Model):
    user = models.ForeignKey(
        to=User,
        on_delete=models.CASCADE
    )

    listing = models.ForeignKey(
        to=Listing,
        on_delete=models.CASCADE
    )
