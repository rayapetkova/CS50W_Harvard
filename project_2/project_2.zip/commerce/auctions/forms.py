from django import forms
from django.core.exceptions import ValidationError

from auctions.models import Listing, Bid, Comment


class ListingForm(forms.ModelForm):

    class Meta:
        model = Listing
        fields = ('title', 'description', 'starting_bid', 'poster_image', 'category')


class BidForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request')
        self.listing_id = kwargs.pop('listing_id')

        super().__init__(*args, **kwargs)

    class Meta:
        model = Bid
        fields = ('price', )

        labels = {
            'price': ''
        }

        widgets = {
            'price': forms.TextInput(attrs={'placeholder': 'Bid'})
        }

    def clean_price(self):
        price = self.cleaned_data['price']
        listing = Listing.objects.filter(id=self.listing_id).first()

        if float(price) > listing.starting_bid:
            listing.starting_bid = float(price)
            listing.save()

            return price
        else:
            raise ValidationError('Bid need to be greater than the current price.')

    def save(self, commit=True):
        bid = super().save(commit=False)

        listing = Listing.objects.filter(id=self.listing_id).first()
        bid.listing = listing
        bid.author = self.request.user

        if commit:
            bid.save()

        return bid


class CommentForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request')
        self.listing_id = kwargs.pop('listing_id')

        super().__init__(*args, **kwargs)

    class Meta:
        model = Comment
        fields = ('content', )

    def save(self, commit=True):
        comment = super().save(commit=False)

        listing = Listing.objects.filter(id=self.listing_id).first()
        comment.listing = listing
        comment.author = self.request.user

        if commit:
            comment.save()

        return comment
