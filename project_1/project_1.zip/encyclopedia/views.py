import random

from django import forms
from django.shortcuts import render, redirect

from . import util

import markdown2


class EntryForm(forms.Form):
    title = forms.CharField(
        label="Title",
        max_length=100
    )

    entry_content = forms.CharField(
        widget=forms.Textarea()
    )

    def clean(self):
        super().clean()

        title = self.cleaned_data.get('title')

        all_entries = util.list_entries()
        if title in all_entries:
            self._errors['title'] = self.error_class(['This title already exists. Provide another one.'])

        return self.cleaned_data


def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })


def entry_info(request, title):
    entry = util.get_entry(title)

    context = {
        'entry': markdown2.markdown(entry),
        'entry_name': title
    }

    if not entry:
        return render(request, 'encyclopedia/not_found_entry_page.html', context=context)

    return render(request, "encyclopedia/entry_info.html", context=context)


def edit_entry(request, title):
    entry = util.get_entry(title)
    context = {
        'entry': entry,
        'entry_name': title
    }
    return render(request, "encyclopedia/edit_entry.html", context=context)


def save_entry(request, title):
    entry_dict = request.GET
    content = entry_dict.get('entry_content')

    util.save_entry(title, content)

    return redirect('entry_info', title=title)


def search_entries(request):
    found_entries = []

    if request.method == "POST":
        entries = util.list_entries()
        searched_string = request.POST['q']

        for entry in entries:
            if searched_string.lower() in entry.lower():
                found_entries.append(entry)

    context = {
        'entries': found_entries
    }

    return render(request, "encyclopedia/index.html", context=context)


def create_new_entry(request):
    if request.method == "POST":
        form = EntryForm(request.POST)

        if form.is_valid():
            title = request.POST['title']
            entry_content = request.POST['entry_content']

            util.save_entry(title, entry_content)
            return redirect("entry_info", title=title)
        else:
            return render(request, "encyclopedia/create_new_entry.html", {'form': form})

    return render(request, "encyclopedia/create_new_entry.html", {'form': EntryForm()})


def choose_random_entry(request):
    all_entries = util.list_entries()
    entries_count = len(all_entries)
    random_int_number = random.randint(0, entries_count - 1)

    return redirect('entry_info', title=all_entries[random_int_number])