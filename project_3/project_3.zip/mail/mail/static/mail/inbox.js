document.addEventListener('DOMContentLoaded', function() {

  // Use buttons to toggle between views
  document.querySelector('#inbox').addEventListener('click', () => load_mailbox('inbox'));
  document.querySelector('#sent').addEventListener('click', () => load_mailbox('sent'));
  document.querySelector('#archived').addEventListener('click', () => load_mailbox('archive'));
  document.querySelector('#compose').addEventListener('click', compose_email);

  // By default, load the inbox
  load_mailbox('inbox');
});

function compose_email() {

  // Show compose view and hide other views
  document.querySelector('#emails-view').style.display = 'none';
  document.querySelector('#compose-view').style.display = 'block';

  // Clear out composition fields
  document.querySelector('#compose-recipients').value = '';
  document.querySelector('#compose-subject').value = '';
  document.querySelector('#compose-body').value = '';

  const submitBtn = document.querySelector('#compose-form .btn')
  submitBtn.addEventListener('click', (e) => {
    e.preventDefault()
    const recipients = document.querySelector('#compose-recipients').value
    const subject = document.querySelector('#compose-subject').value
    const bodyEmail = document.querySelector('#compose-body').value

    const errorText = document.querySelector('#error-text')

    fetch('/emails', {
      method: 'POST',
      body: JSON.stringify({
        recipients,
        subject,
        bodyEmail
      })
    }).then(response => response.json())
        .then(result => {
          if (Object.keys(result).includes('error')) {
            const error = result.error
            errorText.textContent = error
          } else {
            load_mailbox('sent')
          }
        })
  })
}

function load_mailbox(mailbox) {

  const emailsViewContainer = document.querySelector('#emails-view')
  const emailDetailsView = document.querySelector('#email-details-view')

  emailDetailsView.innerHTML = ''
  
  // Show the mailbox and hide other views
  document.querySelector('#emails-view').style.display = 'block';
  document.querySelector('#compose-view').style.display = 'none';

  // Show the mailbox name
  document.querySelector('#emails-view').innerHTML = `<h3>${mailbox.charAt(0).toUpperCase() + mailbox.slice(1)}</h3>`;

  emailsViewContainer.innerHTML = ''

  fetch(`/emails/${mailbox}`)
      .then(response => response.json())
      .then(result => {
        for (let email of result) {
          const divContainer = document.createElement('div')
          divContainer.id = 'email-container'

          const pSender = document.createElement('p')
          pSender.textContent = `From: ${email.sender}`

          const aSubject = document.createElement('a')
          aSubject.textContent = `${email.subject}`
          aSubject.href = '#'

          const pTimestamp = document.createElement('p')
          pTimestamp.textContent = `Time: ${email.timestamp}`

          const addToArchiveButton = document.createElement('button')
          addToArchiveButton.textContent = 'Archive'

          divContainer.appendChild(pSender)
          divContainer.appendChild(aSubject)
          divContainer.appendChild(pTimestamp)

          if (mailbox !== 'sent') {
            divContainer.appendChild(addToArchiveButton)
          }

          emailsViewContainer.appendChild(divContainer)

          aSubject.addEventListener('click', () => {
            emailsViewContainer.style.display = 'none'

            const emailDetailsView = document.querySelector('#email-details-view')

            const pRecipients = document.createElement('p')
            pRecipients.textContent = `To: ${email.recipients}`

            const pSubject = document.createElement('p')
            pSubject.textContent = `Subject: ${email.subject}`

            const pBody = document.createElement('p')
            pBody.textContent = `Body: ${email.body}`

            const replyToEmailButton = document.createElement('button')
            replyToEmailButton.textContent = 'Reply'

            emailDetailsView.appendChild(pSender)
            emailDetailsView.appendChild(pRecipients)
            emailDetailsView.appendChild(pSubject)
            emailDetailsView.appendChild(pTimestamp)
            emailDetailsView.appendChild(pBody)
            emailDetailsView.appendChild(addToArchiveButton)
            emailDetailsView.appendChild(replyToEmailButton)

            fetch(`/emails/${email.id}`, {
              method: 'PUT',
              body: JSON.stringify({
                  read: true
              })
            })

            replyToEmailButton.addEventListener('click', () => {
              emailDetailsView.style.display = 'none'

              compose_email()

              const recipientsField = document.querySelector('#compose-recipients')
              recipientsField.value = email.sender

              const subjectField = document.querySelector('#compose-subject')
              subjectField.value = `Re: ${email.subject}`

              const bodyField = document.querySelector('#compose-body')
              bodyField.value = `On ${email.timestamp} foo@example.com wrote: ${email.body}`
            })
          })

          addToArchiveButton.addEventListener('click', () => {

            if (addToArchiveButton.textContent === 'Archive') {
              fetch(`/emails/${email.id}`, {
                method: 'PUT',
                body: JSON.stringify({
                    archived: true
                })
              })

              addToArchiveButton.textContent = 'Archived'
            } else if (addToArchiveButton.textContent === 'Archived') {
              fetch(`/emails/${email.id}`, {
                method: 'PUT',
                body: JSON.stringify({
                    archived: false
                })
              })

              addToArchiveButton.textContent = 'Archive'
            }
          })
        }
      })
}